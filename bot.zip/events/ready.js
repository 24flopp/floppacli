const { Events } = require('discord.js');

module.exports = {
	name: Events.ClientReady,
	once: true,
	execute(client) {
		console.log(`${c.user.tag} is ready to serve ${client.guilds.cache.size} server(s)!`);
	},
};